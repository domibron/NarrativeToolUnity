using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

namespace SmashKeyboardStudios.NarrativeTool.Editor
{
	public abstract class BaseNode : Node
	{
		internal GUID NodeGUID;


	}
}
